<?php echo value($html); ?>

<?php /**PATH C:\laragon\www\wantrix\vendor\filament\support\resources\views\anonymous-partial.blade.php ENDPATH**/ ?>