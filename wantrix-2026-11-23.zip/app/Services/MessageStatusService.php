<?php

namespace App\Services;

use App\Enums\MessageStatus;
use App\Models\Message;
use Illuminate\Support\Facades\DB;

class MessageStatusService
{
    public function change(
        Message $message,
        MessageStatus $status,
        array $attributes = []
    ): bool {
        return DB::transaction(function () use ($message, $status, $attributes) {
            $lockedMessage = Message::query()
                ->whereKey($message->getKey())
                ->lockForUpdate()
                ->first();

            if (! $lockedMessage) {
                return false;
            }

            $oldStatus = $lockedMessage->status;

            if (! $oldStatus instanceof MessageStatus) {
                return false;
            }

            // A retry must never start sending an already-SENDING message again.
            if (
                $oldStatus === MessageStatus::SENDING
                && $status === MessageStatus::SENDING
            ) {
                return false;
            }

            if ($oldStatus === $status) {
                if ($attributes !== []) {
                    $lockedMessage->update($attributes);
                }

                $message->refresh();

                return true;
            }

            if (! $this->canTransition($oldStatus, $status)) {
                return false;
            }

            $lockedMessage->update([
                ...$attributes,
                'status' => $status,
            ]);

            $lockedMessage->statusHistories()->create([
                'status' => $status,
                'changed_at' => now(),
            ]);

            $message->refresh();

            return true;
        }, 3);
    }

    protected function canTransition(
        MessageStatus $from,
        MessageStatus $to
    ): bool {
        return match ($from) {
            MessageStatus::PENDING => in_array($to, [
                MessageStatus::QUEUED,
                MessageStatus::SENDING,
                MessageStatus::FAILED,
            ], true),

            MessageStatus::QUEUED => in_array($to, [
                MessageStatus::SENDING,
                MessageStatus::FAILED,
            ], true),

            MessageStatus::SENDING => in_array($to, [
                MessageStatus::QUEUED,
                MessageStatus::SENT,
                MessageStatus::FAILED,
            ], true),

            MessageStatus::SENT => in_array($to, [
                MessageStatus::DELIVERED,
                MessageStatus::FAILED,
            ], true),

            MessageStatus::DELIVERED => in_array($to, [
                MessageStatus::READ,
                MessageStatus::FAILED,
            ], true),

            MessageStatus::FAILED => $to === MessageStatus::QUEUED,

            MessageStatus::READ => false,
        };
    }
}
