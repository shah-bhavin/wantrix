<header class="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6">

    <div>
        <?php
        $page = \App\Support\Navigation::current();
        ?>

        <div>
            <h1 class="text-2xl font-bold">
                <?php echo e(\App\Support\Navigation::title()); ?>

            </h1>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($page['description'])): ?>
                <p class="text-sm text-slate-500 mt-1">
                    <?php echo e(\App\Support\Navigation::description()); ?>

                </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <div class="flex items-center gap-4">

        
        <button class="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center">
            🔔
        </button>

        
        <div class="flex items-center gap-3">

            <div class="w-10 h-10 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold">
                <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

            </div>

            <div class="hidden md:block">
                <div class="font-medium text-sm text-slate-800">
                    <?php echo e(auth()->user()->name); ?>

                </div>

                <div class="text-xs text-slate-500">
                    <?php echo e(auth()->user()->email); ?>

                </div>
            </div>

        </div>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>

            <button type="submit"
                class="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-red-200 text-red-600 hover:bg-red-50">

                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-arrow-left-on-rectangle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>

                Logout

            </button>
        </form>

    </div>

</header><?php /**PATH C:\laragon\www\wantrix\resources\views/components/vendor/navbar.blade.php ENDPATH**/ ?>