<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
    $page = \App\Support\Navigation::current();
    ?>
    <title>
        <?php echo e($page['title'] ?? config('app.name')); ?>

        |
        <?php echo e(config('app.name')); ?>

    </title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="bg-slate-100">
    <div class="min-h-screen flex">
        
        <?php if (isset($component)) { $__componentOriginald21d4bdc12c050dce2a4a81cc1030f81 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald21d4bdc12c050dce2a4a81cc1030f81 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.vendor.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('vendor.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald21d4bdc12c050dce2a4a81cc1030f81)): ?>
<?php $attributes = $__attributesOriginald21d4bdc12c050dce2a4a81cc1030f81; ?>
<?php unset($__attributesOriginald21d4bdc12c050dce2a4a81cc1030f81); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald21d4bdc12c050dce2a4a81cc1030f81)): ?>
<?php $component = $__componentOriginald21d4bdc12c050dce2a4a81cc1030f81; ?>
<?php unset($__componentOriginald21d4bdc12c050dce2a4a81cc1030f81); ?>
<?php endif; ?>

        
        <div class="flex-1 flex flex-col">
            
            <?php if (isset($component)) { $__componentOriginal1484ba34de3d2b8a392fe2a69740cf88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1484ba34de3d2b8a392fe2a69740cf88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.vendor.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('vendor.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1484ba34de3d2b8a392fe2a69740cf88)): ?>
<?php $attributes = $__attributesOriginal1484ba34de3d2b8a392fe2a69740cf88; ?>
<?php unset($__attributesOriginal1484ba34de3d2b8a392fe2a69740cf88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1484ba34de3d2b8a392fe2a69740cf88)): ?>
<?php $component = $__componentOriginal1484ba34de3d2b8a392fe2a69740cf88; ?>
<?php unset($__componentOriginal1484ba34de3d2b8a392fe2a69740cf88); ?>
<?php endif; ?>

            
            <main class="flex-1 p-6">


                <?php echo e($slot); ?>

            </main>
        </div>

    </div>
    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
    <script>
        window.metaConfig = {

    appId: "<?php echo e(config('meta.app_id')); ?>",
    configId: "<?php echo e(config('meta.embedded_signup.config_id')); ?>"
};

    </script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>

</html><?php /**PATH C:\laragon\www\wantrix\resources\views/layouts/vendor.blade.php ENDPATH**/ ?>