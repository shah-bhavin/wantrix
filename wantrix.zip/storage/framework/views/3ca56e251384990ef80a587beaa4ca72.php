<div class="h-full flex flex-col">
    <div wire:poll.3s class="flex flex-col h-full min-h-0">

        
        <div class="shrink-0 p-4 border-b bg-white">

            <input wire:model.live.debounce.500ms="search" placeholder="Search..."
                class="w-full rounded-xl border-slate-300">

        </div>


        
        <div class="flex-1 min-h-0 overflow-y-auto">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <button wire:key="conversation-<?php echo e($conversation->id); ?>"
                wire:click="selectConversation(<?php echo e($conversation->id); ?>)"
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([ 'w-full text-left border-b p-4 transition' , 'bg-amber-50'=>
                $selectedConversationId == $conversation->id,

                'hover:bg-slate-50' =>
                $selectedConversationId != $conversation->id,
                ]); ?>"
                >

                <div class="flex justify-between gap-3">

                    <div class="font-semibold truncate">
                        <?php echo e($conversation->contact->name); ?>

                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($conversation->last_message_at): ?>

                    <div class="text-xs text-slate-500 shrink-0">
                        <?php echo e($conversation->last_message_at->format('H:i')); ?>

                    </div>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>


                <div class="text-sm text-slate-500 mt-1">
                    <?php echo e($conversation->contact->phone_number); ?>

                </div>


                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($conversation->unread_count > 0): ?>

                <div class="mt-2">

                    <span class="inline-flex items-center justify-center
                                   min-w-6 h-6
                                   bg-green-600 text-white
                                   rounded-full px-2
                                   text-xs font-medium">
                        <?php echo e($conversation->unread_count); ?>

                    </span>

                </div>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </button>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>

    </div>
</div><?php /**PATH C:\laragon\www\wantrix\resources\views/livewire/vendor/conversation-list.blade.php ENDPATH**/ ?>