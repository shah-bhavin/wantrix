<?php

namespace App\Listeners\Campaigns;

use App\Enums\CampaignActivityType;
use App\Events\CampaignCompleted;
use App\Models\CampaignActivity;

class RecordCampaignCompletedActivity
{
    public function handle(CampaignCompleted $event): void
    {
        $campaign = $event->campaign;

        CampaignActivity::create([
            'campaign_id' => $campaign->id,
            'type' => CampaignActivityType::COMPLETED,
            'description' => 'Campaign finished successfully.',
        ]);
    }
}